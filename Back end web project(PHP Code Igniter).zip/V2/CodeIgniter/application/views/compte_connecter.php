


<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <?php /* if(isset($_SESSION['user']))
{
  if ($_SESSION['type']=="F") {
    redirect("Profil/lister");
  }
  redirect("Accueil/afficher");
    exit;
} */ ?>
<?php echo validation_errors(); ?>
<?php echo form_open('comptes/connecter') ?>
<label>Connectez vous :</label><br>

 <label for="id">Identifiant</label>
 <input type="input" name="pseudo" class="xtn  " /><br />
 <label for="mdp">Mot de passe</label>
 <input type="password" name="mdp"  class="xtn  " /><br />
<input type="submit" value="Connexion" class="btn btn-primary btn-xl js-scroll-trigger" />
</form>

          </div>
        </div>
      </div>
    </header>