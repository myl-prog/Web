
<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">

<style type="text/css">.tg  {border-collapse:collapse;border-spacing:0;border-color:#999;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#999;color:#444;background-color:#F7FDFA;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#999;color:#fff;background-color:#26ADE4;}
.tg .tg-p1nr{font-size:11px;border-color:inherit;text-align:left;vertical-align:top}
.tg .tg-fb1n{background-color:#c0c0c0;border-color:#9b9b9b;text-align:left;vertical-align:top}
.tg .tg-0lax{text-align:left;vertical-align:top}</style>


            <!--
            <form method="post" action=".php">
        <p>
        <label for="match">Le code du match :</label>
        <input type="text" name="match" id="match" placeholder="Code" size="30" maxlength="10" />
        <input type="submit" value="Envoyer" class="btn btn-primary btn-xl js-scroll-trigger" />
        </p>


           </form> -->


           <?php echo validation_errors(); ?>
<?php echo form_open('MatchSelectF/select/1'); ?>
<label for="match">Le code du match :</label>
        <input type="text" name="match" id="match" placeholder="Code" class="xtn "  />
        <input type="submit" name="Envoyer" value="Envoyer" class="btn btn-primary btn-xl js-scroll-trigger" />
</form>


           <?php
           
foreach($match as $login){
 echo "<br />";
 echo " -- ";
echo $login["match_id"];
echo " -- ";
echo $login["match_code"];
echo " -- ";
echo $login["match_intitule"];
echo " -- ";
echo $login["match_situation"];
echo " -- ";
echo $login["match_debut"];
echo " -- ";
echo $login["match_fin"];
echo " -- ";
echo $login["cpt_pseudo"];
echo " -- ";
echo $login["quiz_id"];
echo " -- ";
echo "<br />";
}

?>

<table class="tg" >
 
<tr>
  <th class="tg-fb1n" size="1">
<?php


//echo " -----";
echo "  QST_ID  ";
//echo " ---------- ";
?>
  </th>
  <th class="tg-fb1n" size="1">
<?php
//echo " ----------";
echo "  QST_LIBELLE  ";
//echo " ----- ";
?>
  </th>
  <th class="tg-fb1n" size="1">
<?php
//echo " ----------";
echo "  REP_ID  ";
//echo " ----- ";
?>
  </th>
  <th class="tg-fb1n" size="1">
<?php
//echo " ----------";
echo "  REP_LIBELLE  ";
//echo " ----- ";
?>
  </th>
  <th class="tg-fb1n" size="1">
<?php
//echo " ----------";
echo "  REP_VALEUR  ";
//echo " ----- ";
?>
  </th>
  <th class="tg-fb1n" size="1">
<?php
//echo " ----------";
echo "  REP_ID  ";
//echo " ----- ";
?>
  </th>
  <th class="tg-fb1n" size="1">
<?php
//echo " ----------";
echo "  REP_LIBELLE  ";
//echo " ----- ";
?>
  </th>
  <th class="tg-fb1n" size="1">
<?php
//echo " ----------";
echo "  REP_VALEUR  ";
//echo " ----- ";
?>
  </th>
  
  
</tr>

  
<?php
$IDqst=0;
foreach($qstRep as $qr){
?>

<tr >
<?php  

if ($qr["QST_ID"]<>$IDqst) {
    
    //echo "<br />";
 //echo " -- ";
?>
<td class="tg-0lax" valign=baseline>
<?php  
echo $qr["QST_ID"];
?>
</td>
<?php


?>
<td class="tg-0lax" valign=baseline>
  <input type="" name="" value="<?php  
echo $qr["QST_LIBELLE"];
?>">

</td>
<?php

//echo " -- ";

//echo " ---------- ";
$IDqst=$qr["QST_ID"];

    foreach($qstRep as $r){
            if ($r["QST_ID"]==$IDqst) {

              ?>
<td class="tg-0lax" valign=baseline>
  <input type="" name="" size="1" value="<?php  
echo $r["REP_ID"];?>">

</td>
<?php



?>
<td class="tg-0lax" valign=baseline>
   <input type="" name="" size="4" value="<?php  
echo $r["REP_LIBELLE"];?>">

</td>
<?php



?>
<td class="tg-0lax" valign=baseline>
   <input type="" name="" maxlength="1" size="1" value="<?php  
echo $r["REP_VALEUR"];?>">

</td>
<?php
            
            //echo " -- ";
            
            //echo " ---------- ";
            
            }
            

              }

echo "<br />";
  } 
  ?>
</tr>  
  <?php
 
}
?>
</table> 



          </div>
        </div>
      </div>
    </header>




    <section class="bg-primary" id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <h3 class="section-heading text-white">LES SCORES</h3>
            <hr class="light my-4">
            <p class="text-faded mb-4"><table class="tg">
  <tr>
    <td class="tg-0lax"><?php echo "  jou_id  "; ?></th>
    <td class="tg-0lax"><?php echo "  jou_pseudo  "; ?></th>
    <td class="tg-0lax"><?php echo "  jou_score  "; ?></th>
  </tr>

  
<?php

  foreach ($score as $s) {
    ?>
    <tr>
    <?php
    

?>
<td class="tg-0lax" valign=baseline>
<?php  
echo $s["jou_id"];
?>
</td>
<?php


?>
<td class="tg-0lax" valign=baseline>
<?php  
echo $s["jou_pseudo"];
?>
</td>
<?php


?>
<td class="tg-0lax" valign=baseline>
<?php  
echo $s["jou_score"];
?>
</td>
</tr>
<?php





  }


?>


</table></p>
          </div>
        </div>
      </div>
    </section>

<!--echo $qr["REP_ID"];
echo " -- ";
echo $qr["REP_LIBELLE"];
echo " -- ";
echo $qr["REP_VALEUR"];
echo " -- ";  -->
     

<!--
     <table class="tg" >
 <tr>
  <th>bla</th>
 </tr>
 <tr>
  <td class="tg-0lax" valign=baseline>bla</td>
 </tr>
</table>   -->