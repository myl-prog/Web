
<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">




            <!--
            <form method="post" action=".php">
        <p>
        <label for="match">Le code du match :</label>
        <input type="text" name="match" id="match" placeholder="Code" size="30" maxlength="10" />
        <input type="submit" value="Envoyer" class="btn btn-primary btn-xl js-scroll-trigger" />
        </p>


           </form> -->


           <?php echo validation_errors(); ?>
<?php echo form_open('MatchSelect/selectA/1'); ?>
<label for="match">Le code du match :</label>
        <input type="text" name="match" id="match" placeholder="Code" class="xtn "  />
        <input type="submit" value="Envoyer" class="btn btn-primary btn-xl js-scroll-trigger" />
</form>


           <?php
           
foreach($match as $login){
 echo "<br />";
 echo " -- ";
echo $login["match_id"];
echo " -- ";
echo $login["match_code"];
echo " -- ";
echo $login["match_intitule"];
echo " -- ";
echo $login["match_situation"];
echo " -- ";
echo $login["match_debut"];
echo " -- ";
echo $login["match_fin"];
echo " -- ";
echo $login["cpt_pseudo"];
echo " -- ";
echo $login["quiz_id"];
echo " -- ";
echo "<br />";
}

?>

<table >
 
<tr>
  <th size="1">
<?php


//echo " -----";
echo "  QST_ID  ";
//echo " ---------- ";
?>
  </th>
  <th size="1">
<?php
//echo " ----------";
echo "  QST_LIBELLE  ";
//echo " ----- ";
?>
  </th>
  <th size="1">
<?php
//echo " ----------";
echo "  REP_ID  ";
//echo " ----- ";
?>
  </th>
  <th size="1">
<?php
//echo " ----------";
echo "  REP_LIBELLE  ";
//echo " ----- ";
?>
  </th>
  <th size="1">
<?php
//echo " ----------";
echo "  REP_VALEUR  ";
//echo " ----- ";
?>
  </th>
  <th size="1">
<?php
//echo " ----------";
echo "  REP_ID  ";
//echo " ----- ";
?>
  </th>
  <th size="1">
<?php
//echo " ----------";
echo "  REP_LIBELLE  ";
//echo " ----- ";
?>
  </th>
  <th size="1">
<?php
//echo " ----------";
echo "  REP_VALEUR  ";
//echo " ----- ";
?>
  </th>
  
  
</tr>

  
<?php
$IDqst=0;
foreach($qstRep as $qr){
?>

<tr >
<?php  

if ($qr["QST_ID"]<>$IDqst) {
    
    //echo "<br />";
 //echo " -- ";
?>
<td valign=baseline>
<?php  
echo $qr["QST_ID"];
?>
</td>
<?php


?>
<td valign=baseline>
  <input type="" name="" value="<?php  
echo $qr["QST_LIBELLE"];
?>">

</td>
<?php

//echo " -- ";

//echo " ---------- ";
$IDqst=$qr["QST_ID"];

    foreach($qstRep as $r){
            if ($r["QST_ID"]==$IDqst) {

              ?>
<td valign=baseline>
  <input type="" name="" size="1" value="<?php  
echo $r["REP_ID"];?>">

</td>
<?php



?>
<td valign=baseline>
   <input type="" name="" size="4" value="<?php  
echo $r["REP_LIBELLE"];?>">

</td>
<?php



?>
<td valign=baseline>
   <input type="" name="" maxlength="1" size="1" value="<?php  
echo $r["REP_VALEUR"];?>">

</td>
<?php
            
            //echo " -- ";
            
            //echo " ---------- ";
            
            }
            

              }

echo "<br />";
  } 
  ?>
</tr>  
  <?php
 
}
?>
</table> 



          </div>
        </div>
      </div>
    </header>




    <section class="bg-primary" id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <h3 class="section-heading text-white">LES SCORES</h3>
            <hr class="light my-4">
            <p class="text-faded mb-4"><table>
  <tr>
    <th><?php echo "  jou_id  "; ?></th>
    <th><?php echo "  jou_pseudo  "; ?></th>
    <th><?php echo "  jou_score  "; ?></th>
  </tr>

  
<?php

  foreach ($score as $s) {
    ?>
    <tr>
    <?php
    

?>
<td valign=baseline>
<?php  
echo $s["jou_id"];
?>
</td>
<?php


?>
<td valign=baseline>
<?php  
echo $s["jou_pseudo"];
?>
</td>
<?php


?>
<td valign=baseline>
<?php  
echo $s["jou_score"];
?>
</td>
</tr>
<?php





  }


?>


</table></p>
          </div>
        </div>
      </div>
    </section>

<!--echo $qr["REP_ID"];
echo " -- ";
echo $qr["REP_LIBELLE"];
echo " -- ";
echo $qr["REP_VALEUR"];
echo " -- ";  -->
     

<!--
     <table >
 <tr>
  <th>bla</th>
 </tr>
 <tr>
  <td valign=baseline>bla</td>
 </tr>
</table>   -->