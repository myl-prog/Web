  <style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;border-width:1px;border-style:solid;border-color:#bbb;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#bbb;color:#594F4F;background-color:#E0FFEB;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#bbb;color:#493F3F;background-color:#9DE0AD;}
.tg .tg-p1nr{font-size:11px;border-color:inherit;text-align:left;vertical-align:top}
.tg .tg-fb1n{background-color:#c0c0c0;border-color:#9b9b9b;text-align:left;vertical-align:top}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
</style>


  <section class="">
      <div class="container text-center">
        <h3><?php echo $titreF; ?></h3>

        <table class="tg" >
 <tr class="xtn">
   <th class="tg-fb1n" size="1">match_id</th>
   <th class="tg-fb1n" size="1">match_code</th>
   <th class="tg-fb1n" size="1">match_intitule</th>
   <th class="tg-fb1n" size="1">match_situation</th>
 </tr>

        <?php
        
foreach($matchs as $login){
 ?><tr class="xtn">
  <th class="tg-0lax" size="1"><?php
 echo $login["match_id"];
 ?></th><th class="tg-0lax" size="1"><?php
 
 echo $login["match_code"];
 ?></th><th class="tg-0lax" size="1"><?php
 echo $login["match_intitule"];
 ?></th><th class="tg-0lax" size="1"><?php
 echo $login["match_situation"];
 ?></th><?php
 ?></tr><?php
 
 
}
?>


<tr>
<?php echo validation_errors(); ?>
<?php echo form_open('MatchSelectF/select/1'); ?>
<th class="tg-0lax">

</td>
<th class="tg-0lax">
<label for="match">match_code :</label>
        <input type="text"  name="match" id="match" placeholder="" class="xtn "  />
</td>
<th class="tg-0lax">
<label for="match">match_intitule :</label>
        <input type="text" name="match_intitule" id="match_intitule" placeholder="" class="xtn "  />
</td>
<th class="tg-0lax">
<label for="match">match_situation :</label>
        <input type="text" name="match_situation" id="match_situation" placeholder="" class="xtn "  />
</td>
<th class="tg-0lax">
        <input type="submit" name="Modifier" value="Modifier" class="xtn" /><input type="submit" name="Supprimer" value="Supprimer" class="xtn" />
</td>
</form>
</tr>
</table>
      </div>
    </section>
