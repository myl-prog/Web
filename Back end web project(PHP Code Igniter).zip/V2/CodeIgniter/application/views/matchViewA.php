 
    <section class="bg-dark text-white">
      <div class="container text-center">
        <h3><?php echo $titreA; ?></h3>
        <?php
        
foreach($matchs as $login){
 echo "<br />";
 echo " -- ";
 echo $login["match_id"];
 echo " -- ";
 echo $login["match_code"];
 echo " -- ";
 echo $login["match_intitule"];
 echo " -- ";
 echo " -- ";
 echo $login["match_situation"];
 echo " -- ";
 echo " -- ";
 echo $login["cpt_pseudo"];
 echo " -- ";
 echo "<br />";
}
?>
      </div>
    </section>
