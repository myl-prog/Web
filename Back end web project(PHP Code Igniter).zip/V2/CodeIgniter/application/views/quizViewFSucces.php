


<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h2 class="text-uppercase">
              <?php echo "Liste des quizs";?>
            </h1>
            <hr>
          </div>
          
            <h1></h1>
<br />
<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;border-width:1px;border-style:solid;border-color:#bbb;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#bbb;color:#594F4F;background-color:#E0FFEB;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#bbb;color:#493F3F;background-color:#9DE0AD;}
.tg .tg-p1nr{font-size:11px;border-color:inherit;text-align:left;vertical-align:top}
.tg .tg-fb1n{background-color:#c0c0c0;border-color:#9b9b9b;text-align:left;vertical-align:top}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
</style>
<?php $_SESSION['quiz_id']=0; ?>
<table class="tg">
  <thead>
  <tr>
    <td class="tg-fb1n">quiz_id</td>
    <td class="tg-fb1n">quiz_intitulé</td>
    <td class="tg-fb1n">quiz_descriptif</td>
    <td class="tg-fb1n">quiz_img</td>
    <td class="tg-fb1n">quiz_etat</td>
    <td class="tg-fb1n">cpt_pseudo</td>

  </tr>
  </thead>
  <tbody>
<?php
foreach($quiz as $login){ 
 //echo "<br />";
 //echo " -- ";
  if($login["cpt_pseudo"]==$_SESSION['user']){
      ?>
  <?php echo validation_errors(); ?>
  <?php echo form_open('Quiz/afficherF'); ?>
  <tr>
    <td class="tg-0lax" >
      <input type="text" name="quiz_id" size="1"value="<?php
echo $login["quiz_id"];
  ?>">
  
    </td>
  <?php
  ?>
  
    <td class="tg-0lax">
      <input type="text" name="quiz_intitule" value="<?php
echo $login["quiz_intitule"];
  ?>">
    </td>

  <?php
  ?>
  
    <td class="tg-0lax">
      <input type="text" name="quiz_descriptif" value="<?php
echo $login["quiz_descriptif"];
  ?>">
  
    </td>
  
  <?php
  ?>
  
    <td class="tg-0lax">
  <?php
echo $login["quiz_img"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td class="tg-0lax">
      <input type="text" size="1" name="quiz_etat" value="<?php
echo $login["quiz_etat"];
  ?>">
  
    </td>
    <td class="tg-0lax">
  <?php
echo $login["cpt_pseudo"];
  ?>
    </td>
  
  <?php
  ?>
  
    
      <td class="tg-0lax">
        <input type="submit" name="Modifier" value="Modifier" class="xtn" />  <input type="submit" name="Supprimer" value="Supprimer" class="xtn" />
    </td>
    </form>
  </tr>
  
  <?php

  }
  else{
    ?>
  
  <tr>
    <td class="tg-0lax">
  <?php
echo $login["quiz_id"];
  ?>
    </td>
  <?php
  ?>
  
    <td class="tg-0lax">
  <?php
echo $login["quiz_intitule"];
  ?>
    </td>

  <?php
  ?>
  
    <td class="tg-0lax">
  <?php
echo $login["quiz_descriptif"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td class="tg-0lax">
  <?php
echo $login["quiz_img"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td class="tg-0lax">
  <?php
echo $login["quiz_etat"];
  ?>
    </td>
    <td class="tg-0lax">
  <?php
echo $login["cpt_pseudo"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td class="tg-0lax"></td>


    
  </tr>
  
  <?php


  }













  ?>
  
  
  
  <?php
//echo " -- ";
//echo "<br />";
}
echo $_SESSION['quiz_id'];
?>

</tbody>
</table>


        
<h2 class="col-lg-10 mx-auto"> Modification Réussie</h2>

















          
        </div>
      </div>
    </header>