


<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <h1><?php echo "Liste des quizs";?></h1>
<br />

<table>
  <thead>
  <tr>
    <td>quiz_id</td>
    <td>quiz_intitulé</td>
    <td>quiz_descriptif</td>
    <td>quiz_img</td>
    <td>quiz_etat</td>
  </tr>
  </thead>
  <tbody>
<?php
foreach($quiz as $login){
 //echo "<br />";
 //echo " -- ";
  ?>
  
  <tr>
    <td>
  <?php
echo $login["CPT_PSEUDO"];
  ?>
    </td>
  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_prenom"];
  ?>
    </td>

  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_nom"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_type"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_actif"];
  ?>
    </td>
  </tr>
  
  <?php
//echo " -- ";
//echo "<br />";
}

?>
</tbody>
</table>
            
          </div>
        </div>
      </div>
    </header>