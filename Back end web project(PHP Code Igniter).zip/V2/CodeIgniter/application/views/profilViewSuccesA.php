
<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <h1><?php echo $titre;?></h1>
<br />



<?php echo validation_errors();  ?>
<?php echo form_open('profil/listerA') ?>

<label>Votre profil :</label><br>
<label>Pseudo :</label>
<input type="text" name="id" value="<?php echo $profil->cpt_pseudo;?>  " class="xtn  " /><br>
<label>Pour modifier votre mot de passe :</label>
<input type="password" name="mdp"  class="xtn  " /><br>
<label>Retaper votre nouveau mot de passe :</label>
<input type="password" name="mdp2"  class="xtn  " /><br>
<label> Nom:</label>
<input type="input" name="nom" value="<?php echo $profil->cpt_nom;?>" class="xtn  " /><br>
<label>Votre prenom:</label>
<input type="input" name="prenom" value="<?php echo $profil->cpt_prenom;?>" class="xtn  " /><br>
<label>Type de compte :</label>
<input type="input" name="type" value="<?php echo $profil->cpt_type;?>" class="xtn  " /><br>
<label>Actif ou pas  :</label>
<input type="input" name="actif" value="<?php echo $profil->cpt_actif;?>" class="xtn  " /><br>
<h4>Modification prise en compte avec succés !</h4>

<input type="submit" value="Modifier"/>
</form>

<a type="submit" class="xtn" value="Annuler" href="<?php echo base_url();?>index.php/Profil/listerA"/>Annuler</a>


            
          </div>
        </div>
      </div>
    </header>


















