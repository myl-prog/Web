


<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <h1><?php echo "Liste des quizs";?></h1>
<br />

<table>
  <thead>
  <tr>
    <td>quiz_id</td>
    <td>quiz_intitulé</td>
    <td>quiz_descriptif</td>
    <td>quiz_img</td>
    <td>quiz_etat</td>
    <td>cpt_pseudo</td>

  </tr>
  </thead>
  <tbody>
<?php
foreach($quiz as $login){
 //echo "<br />";
 //echo " -- ";
  ?>
  
  <tr>
    <td>
  <?php
echo $login["quiz_id"];
  ?>
    </td>
  <?php
  ?>
  
    <td>
  <?php
echo $login["quiz_intitule"];
  ?>
    </td>

  <?php
  ?>
  
    <td>
  <?php
echo $login["quiz_descriptif"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td>
  <?php
echo $login["quiz_img"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td>
  <?php
echo $login["quiz_etat"];
  ?>
    </td>
    <td>
  <?php
echo $login["cpt_pseudo"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td>
  </tr>
  
  <?php
//echo " -- ";
//echo "<br />";
}

?>
</tbody>
</table>
            
          </div>
        </div>
      </div>
    </header>