


<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <?php echo validation_errors(); ?>
<?php echo form_open('compte_creer'); ?>
 <label for="id">Identifiant</label>
 <input type="input" name="id" class="xtn  " /><br />
 <label for="mdp">Mot de passe</label>
 <input type="password" name="mdp"  class="xtn  " /><br />
 <input type="submit" name="submit" value="Créer"  class="btn btn-primary js-scroll-trigger" />
</form>
            
          </div>
        </div>
      </div>
    </header>