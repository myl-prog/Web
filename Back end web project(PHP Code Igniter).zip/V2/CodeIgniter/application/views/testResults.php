<h1>Vos réponses: <?php echo $a1; echo $a2; echo $a3 , $a4 ,$a5;  ?> </h1>

<h1>Votre score: <?php echo $score ,"   ", $Q;  ?> </h1>



