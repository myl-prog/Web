


<header class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="text-uppercase">
              
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <h1><?php echo $titre;?></h1>
<br />

<table>
  <thead>
  <tr>
    <td>CPT_PSEUDO</td>
    <td>CPT_NOM</td>
    <td>CPT_PRENOM</td>
    <td>CPT_TYPE</td>
    <td>CPT_ACTIF</td>
  </tr>
  </thead>
  <tbody>
<?php
foreach($pseudos as $login){
 //echo "<br />";
 //echo " -- ";
  ?>
  
  <tr>
    <td>
  <?php
echo $login["CPT_PSEUDO"];
  ?>
    </td>
  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_prenom"];
  ?>
    </td>

  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_nom"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_type"];
  ?>
    </td>
  
  <?php
  ?>
  
    <td>
  <?php
echo $login["cpt_actif"];
  ?>
    </td>
  </tr>
  
  <?php
//echo " -- ";
//echo "<br />";
}

?>
</tbody>
</table>
            
          </div>
        </div>
      </div>
    </header>