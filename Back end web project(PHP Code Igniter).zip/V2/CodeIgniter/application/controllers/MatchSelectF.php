<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MatchSelectF extends CI_Controller {


 public function __construct()
 {
 parent::__construct();
 $this->load->model('db_model');
 $this->load->helper('url_helper');
 }

 public function select($arg)
 {
 $data['titreF'] = 'Liste de mes matchs :';
 $data['matchs'] = $this->db_model->get_matchF($_SESSION['user']);


 
 $data['titre'] = 'Le match :';
 $data['match'] = $this->db_model->get_match($arg);
 $data['qstRep'] = $this->db_model->get_qst_rep($arg);
 $data['score']=$this->db_model->get_score($arg);
 $this->load->helper('form');
 $this->load->library('form_validation');


if (isset ($_POST['Envoyer'])){


 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('match', 'match', 'required');

 if ($this->form_validation->run() == FALSE)
 {
 $this->load->view('templates/headerF');
 $this->load->view('matchViewF',$data);
 $this->load->view('matchSelectViewF',$data);
 $this->load->view('templates/footerF');
 }
 else
 {
 $code=htmlspecialchars(addslashes($this->input->post('match'))); 
 $data['match'] = $this->db_model->get_match($code);
 $data['qstRep'] = $this->db_model->get_qst_rep($code);
 $data['score']=$this->db_model->get_score($code);
 $this->load->view('templates/headerF');
 $this->load->view('matchViewF',$data);
 $this->load->view('matchSelectViewF',$data);
 $this->load->view('templates/footerF');
 }

}

elseif (isset ($_POST['Modifier'])) {
 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('match', 'match', 'required');
 
 $this->form_validation->set_rules('match_intitule', 'match_intitule');
 $this->form_validation->set_rules('match_situation', 'match_situation');

 if ($this->form_validation->run() == FALSE)
 {
 $this->load->view('templates/headerF');
 $this->load->view('matchViewF',$data);
 $this->load->view('matchSelectViewF',$data);
 $this->load->view('templates/footerF');
 }
 else
 {  
 $code=htmlspecialchars(addslashes($this->input->post('match')));
										 if ($this->db_model->update_match($code)) {
										 	 $data['match'] = $this->db_model->get_match($code);
											 $data['qstRep'] = $this->db_model->get_qst_rep($code);
											 $data['score']=$this->db_model->get_score($code);
											 $this->load->view('templates/headerF');
											 $this->load->view('matchViewF',$data);
											 $this->load->view('matchSelectViewF',$data);
											 $this->load->view('templates/footerF');
											 
										 } 
										 else{
										 		$data['match'] = $this->db_model->get_match($code);
											 $data['qstRep'] = $this->db_model->get_qst_rep($code);
											 $data['score']=$this->db_model->get_score($code);
											 $this->load->view('templates/headerF');
											 $this->load->view('matchViewF',$data);
											 $this->load->view('matchSelectViewF',$data);
											 $this->load->view('templates/footerF');
										 }


 
 }
}

elseif (isset ($_POST['Supprimer'])) {
	 $this->load->helper('form');
	 $this->load->library('form_validation');
	 $this->form_validation->set_rules('match', 'match', 'required');




					if ($this->form_validation->run() == FALSE)
				 {
				 $this->load->view('templates/headerF');
				 $this->load->view('matchViewF',$data);
				 $this->load->view('matchSelectViewF',$data);
				 $this->load->view('templates/footerF');
				 }
				 else
				 {  
				 $code=htmlspecialchars(addslashes($this->input->post('match')));
				 $this->db_model->delete_match($code);
				 $data['match'] = $this->db_model->get_match($code);
											 $data['qstRep'] = $this->db_model->get_qst_rep($code);
											 $data['score']=$this->db_model->get_score($code);
											 $this->load->view('templates/headerF');
											 $this->load->view('matchViewF',$data);
											 $this->load->view('matchSelectViewF',$data);
											 $this->load->view('templates/footerF');
				}
}
else{



 $this->load->view('templates/headerF');
 $this->load->view('matchViewF',$data);
 $this->load->view('matchSelectViewF',$data);
 $this->load->view('templates/footerF');
}


 











 
 }

}
?>