<?php
class Deconnexion extends CI_Controller {
    public function __construct() {
        parent::__construct();
       $this->load->model('db_model');
 $this->load->helper('url_helper');
 }


 public function detruire()
 {
 	$this->session->sess_destroy();
        redirect('comptes/connecter');
 }


    
}
?>