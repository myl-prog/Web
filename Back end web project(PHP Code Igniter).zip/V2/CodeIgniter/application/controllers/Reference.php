<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reference extends CI_Controller {

	public function __construct()
 {
 parent::__construct();
 $this->load->helper('url');
 }


	public function afficher()
	{
		$this->load->view('viewReference');
		
	}
}


