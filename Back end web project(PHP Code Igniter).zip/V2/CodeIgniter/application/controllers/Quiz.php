<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Quiz extends CI_Controller {


 public function __construct()
 {
 parent::__construct();
 $this->load->model('db_model');
 $this->load->helper('url_helper');
 }

 public function afficherF()
 {

 	$this->load->helper('form');
 $this->load->library('form_validation');

 if (isset($_POST['Modifier'])) {
 	

 $this->form_validation->set_rules('quiz_id', 'quiz_id','required');
 $this->form_validation->set_rules('quiz_intitule', 'quiz_intitule' );
 $this->form_validation->set_rules('quiz_descriptif', 'quiz_descriptif' );
 $this->form_validation->set_rules('quiz_etat', 'quiz_etat' );
 
					 if ($this->form_validation->run() == NULL) {
					 $data['quiz']=$this->db_model->get_all_quiz();
					 $this->load->view('templates/headerF');
					 $this->load->view('quizViewF',$data);
					 $this->load->view('templates/footerF');
					 }
					 else{
					 $arg=htmlspecialchars(addslashes($this->input->post('quiz_id')));
					 $this->db_model->update_quiz($arg);
					 $data['quiz']=$this->db_model->get_all_quiz();
					 $this->load->view('templates/headerF');
					 $this->load->view('quizViewFSucces',$data);
					 $this->load->view('templates/footerF');
					 }

 }
 elseif (isset($_POST['Supprimer'])) {
 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('quiz_id', 'quiz_id','required'); 	
					if ($this->form_validation->run() == NULL) {
					 $data['quiz']=$this->db_model->get_all_quiz();
					 $this->load->view('templates/headerF');
					 $this->load->view('quizViewF',$data);
					 $this->load->view('templates/footerF');
					 }
					 else{
					 	$arg=htmlspecialchars(addslashes($this->input->post('quiz_id')));
					 	$this->db_model->delete_quiz($arg);
					 	$data['quiz']=$this->db_model->get_all_quiz();
					 	$this->load->view('templates/headerF');
					 $this->load->view('quizViewF',$data);
					 $this->load->view('templates/footerF');
					 }

 }
 elseif (isset($_POST['Creer'])) {
 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('quiz_id', 'quiz_id','required'); 	
					if ($this->form_validation->run() == NULL) {
					 $data['quiz']=$this->db_model->get_all_quiz();
					 $this->load->view('templates/headerF');
					 $this->load->view('quizViewF',$data);
					 $this->load->view('templates/footerF');
					 }
					 else{
					 	$arg=htmlspecialchars(addslashes($this->input->post('quiz_id')));
					 	$this->db_model->insert_quiz($arg);
					 	$data['quiz']=$this->db_model->get_all_quiz();
					 	$this->load->view('templates/headerF');
					 $this->load->view('quizViewF',$data);
					 $this->load->view('templates/footerF');
					 }

 }
 else{

					$data['quiz']=$this->db_model->get_all_quiz();
					 $this->load->view('templates/headerF');
					 $this->load->view('quizViewF',$data);
					 $this->load->view('templates/footerF');



 }

 }



 public function afficherA()
 {


 
 
 $data['quiz']=$this->db_model->get_all_quiz();
 $this->load->view('templates/headerA');
 $this->load->view('quizViewF',$data);
 $this->load->view('templates/footerA');
 

 }

}
?>