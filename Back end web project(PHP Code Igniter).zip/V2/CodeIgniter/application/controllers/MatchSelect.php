<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MatchSelect extends CI_Controller {


 public function __construct()
 {
 parent::__construct();
 $this->load->model('db_model');
 $this->load->helper('url_helper');
 }

 public function selectF($arg)
 {

 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('match', 'match', 'required');

 $data['titre'] = 'Le match :';
 $data['match'] = $this->db_model->get_match($arg);
 $data['qstRep'] = $this->db_model->get_qst_rep($arg);
 if ($this->form_validation->run() == FALSE)
 {
 $this->load->view('templates/headerF');
 $this->load->view('matchSelectView',$data);
 $this->load->view('templates/footerF');
 }
 else
 {
 $id=$this->input->post('match');
 $data['match'] = $this->db_model->get_match($id);
 $data['qstRep'] = $this->db_model->get_qst_rep($id);
 $this->load->view('templates/headerF');
 $this->load->view('matchSelectView',$data);
 $this->load->view('templates/footerF');
 }

 
 }


 public function select($arg)
 {

 $this->load->helper('form');
 $this->load->library('form_validation');
 

 $data['titre'] = 'Le match :';
 $data['match'] = $this->db_model->get_match($arg);
 $data['qstRep'] = $this->db_model->get_qst_rep($arg);

if (isset ($_POST['Envoyer'])){
	$this->load->helper('form');
 	$this->load->library('form_validation');
	$this->form_validation->set_rules('match', 'match', 'required');
	if ($this->form_validation->run() == FALSE)
 {

 $this->load->view('templates/header');
 $this->load->view('matchSelectView',$data);
 $this->load->view('templates/footer');
 }
 else
 {
 $id=$this->input->post('match');
 $data['match'] = $this->db_model->get_match($id);
 $data['qstRep'] = $this->db_model->get_qst_rep($id);
 $this->load->view('templates/header');
 $this->load->view('matchSelectView',$data);
  $this->load->view('templates/footer');
 }
}

elseif (isset ($_POST['results'])) {
	$this->load->helper('form');
 	$this->load->library('form_validation');
 	$this->form_validation->set_rules('1', '1', 'required');
 	$this->form_validation->set_rules('2', '2', 'required');
 	$this->form_validation->set_rules('3', '3', 'required');
 	$this->form_validation->set_rules('4', '4', 'required');
 	$this->form_validation->set_rules('5', '5', 'required');

	if ($this->form_validation->run() == FALSE)
 {
 
 $this->load->view('templates/header');
 $this->load->view('matchSelectView',$data);
 $this->load->view('templates/footer');
 
 }
 else
 {

 $data['match'] = $this->db_model->get_match($_POST['code']);
 $data['qstRep'] = $this->db_model->get_qst_rep($_POST['code']);
 $data['score'] = $this->db_model->results($_POST['1'],$_POST['2'],$_POST['3'],$_POST['4'],$_POST['5'],$_POST['code'],$_POST['Q']);
 $data['a1']=$_POST['1'];
 $data['a2']=$_POST['2'];
 $data['a3']=$_POST['3'];
 $data['a4']=$_POST['4'];
 $data['a5']=$_POST['5'];
 $data['Q']=$_POST['Q'];
 $this->load->view('templates/header');
 $this->load->view('matchSelectView',$data);
 $this->load->view('testResults',$data);
 $this->load->view('templates/footer');
 
 }
	
}


else{
	if ($this->form_validation->run() == FALSE)
 {
 $this->load->view('templates/header');
 $this->load->view('matchSelectView',$data);
 $this->load->view('templates/footer');
 }
 else
 {
 $this->load->view('templates/header');
 $this->load->view('matchSelectView',$data);
 $this->load->view('templates/footer');
 }
}

 

 
 }








public function selectA($arg)
 {

 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('match', 'match', 'required');
 $data['titreA'] = 'Liste des Matchs :';
 $data['matchs'] = $this->db_model->get_all_match();



 $data['titre'] = 'Le match :';
 $data['match'] = $this->db_model->get_match($arg);
 $data['qstRep'] = $this->db_model->get_qst_rep($arg);
 $data['score']=$this->db_model->get_score($arg);
 if ($this->form_validation->run() == FALSE)
 {
 $this->load->view('templates/headerA');
 $this->load->view('matchViewA',$data);
 $this->load->view('matchSelectViewA',$data);
 $this->load->view('templates/footerA');
 }
 else
 {
 $code=$this->input->post('match');
 $data['match'] = $this->db_model->get_match($code);
 $data['qstRep'] = $this->db_model->get_qst_rep($code);
 $data['score']=$this->db_model->get_score($code);
 
 $this->load->view('templates/headerA');
 $this->load->view('matchViewA',$data);
 $this->load->view('matchSelectViewA',$data);
 $this->load->view('templates/footerA');
 }


}












}
?>