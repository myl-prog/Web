<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Comptes extends CI_Controller {


 public function __construct()
 {
 parent::__construct();
 $this->load->model('db_model');
 $this->load->helper('url_helper');
 }



/* LISTAGE */



 public function lister()
 {
 $data['titre'] = 'Liste des pseudos :';
 $data['pseudos'] = $this->db_model->get_all_compte();

 $this->load->view('templates/header');
 $this->load->view('comptes_view',$data);
 $this->load->view('templates/footer');
 }






public function listerA()
 {
 $data['titre'] = 'Liste des comptes :';
 $data['pseudos'] = $this->db_model->get_all_compte();

 $this->load->view('templates/headerA');
 $this->load->view('comptes_viewA',$data);
 $this->load->view('templates/footerA');
 }






/* CONNEXION  */



public function connecter()
{


	if (!isset($_SESSION['user'])) {


							$this->load->helper('form');
							$this->load->library('form_validation');
							$this->form_validation->set_rules('pseudo', 'pseudo', 'required');
							$this->form_validation->set_rules('mdp', 'mdp', 'required');

							 if ($this->form_validation->run() == FALSE)
							 {
							 $this->load->view('templates/header');
							 $this->load->view('compte_connecter');
							 $this->load->view('templates/footer');
							 }
							 else
							 {
							 $user = $this->input->post('pseudo');
							 $username=htmlspecialchars(addslashes($user));
							 $password =htmlspecialchars(addslashes($this->input->post('mdp'))) ;

							 //SEL
							// On rajoute du sel...
							// pour empêcher les attaques par "Rainbow Tables" cf
							// http://en.wikipedia.org/wiki/Rainbow_table

							$salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";

							//HASHAGE
							$PassAvantHash=$password;


							$PassAprésHash=hash('sha256', $salt.$PassAvantHash);
							 if($this->db_model->connect_compte($username,$PassAprésHash))
							 {
							 	$_SESSION['test'] ="";
							 	$_SESSION['user'] = $username;
							 	$_SESSION['quiz_id']='a';
							 	$data[$_SESSION['quiz_id']]=12;
							 	$session_data = array('username' => $username );

							 	$this->session->set_userdata($session_data);
								 if ($this->db_model->for_sinon_ad($username)) {
							 		$_SESSION['type']="F";

							 		$this->load->view('templates/headerF');
							 		$this->load->view('compte_menu',$data);
								 	$this->load->view('templates/footerF');
									}
								else {
									$_SESSION['type']="A";
									$this->load->view('templates/headerA');
									$this->load->view('compte_menu',$data);
									$this->load->view('templates/footerA');

									}
							 
							 }
							 else
							 {
							 $this->load->view('templates/header');
							 $this->load->view('compte_connecterErreur');
							 $this->load->view('templates/footer');
							 }


							 }
		
	

					}


		else{

				if ($this->db_model->for_sinon_ad($_SESSION['user'])) {
							 		$_SESSION['type']="F";
							 		$this->load->view('templates/headerF');
							 		$this->load->view('compte_menu');
								 	$this->load->view('templates/footerF');
									}
								else {
									$_SESSION['type']="A";
									$this->load->view('templates/headerA');
									$this->load->view('compte_menu');
									$this->load->view('templates/footerA');

									}

		}





}





/*CREATION DE COMPTE */



public function creer()
 {
 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('id', 'id', 'required');
 $this->form_validation->set_rules('mdp', 'mdp', 'required');
 if ($this->form_validation->run() == FALSE)
 {
 $this->load->view('templates/header');
 $this->load->view('compte_creer');
 $this->load->view('templates/footer');
 }
 else
 {
 $this->db_model->set_compte();
 $this->load->view('templates/header');
 $this->load->view('compte_succes');
 $this->load->view('templates/footer');
 }



}







/* */
}
?>