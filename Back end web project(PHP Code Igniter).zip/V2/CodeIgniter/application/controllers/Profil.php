<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Profil extends CI_Controller {


 public function __construct()
 {
 parent::__construct();
 $this->load->model('db_model');
 $this->load->helper('url_helper');
 }





public function lister()
 {
 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('mdp', 'mdp','required' );
 $this->form_validation->set_rules('mdp2', 'mdp2','required' );
 $this->form_validation->set_rules('nom', 'prenom','required' );
 $this->form_validation->set_rules('prenom', 'prenom','required' );
 $this->form_validation->set_rules('type', 'type','required' );
 $this->form_validation->set_rules('actif', 'actif','required' );
 $pseudo=$_SESSION['user'];
 $data['titre'] = $pseudo;
 $data['profil'] = $this->db_model->get_profil($pseudo);
if ($this->form_validation->run() == FALSE)
 {
 $data['test']=$this->form_validation->run();
 $this->load->view('templates/headerF');
 $this->load->view('profilView',$data);
 $this->load->view('templates/footerF');
 }
 else
 {
$pass1=htmlspecialchars(addslashes($this->input->post('mdp')));
$pass2=htmlspecialchars(addslashes($this->input->post('mdp2')));

//////////////////VERIF MOT DE PASSE





if ($pass1==$pass2) {

	//SEL
// On rajoute du sel...
// pour empêcher les attaques par "Rainbow Tables" cf
// http://en.wikipedia.org/wiki/Rainbow_table

$salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";

//HASHAGE
$PassAvantHash=$pass1;


 $_SESSION['PassAprésHash']=hash('sha256', $salt.$PassAvantHash);
 $pass=$_SESSION['PassAprésHash'];

 if ($this->db_model->update_profil($pseudo,$pass)) {
 	$data['profil'] = $this->db_model->get_profil($pseudo);
 	$this->load->view('templates/headerF');
 	$this->load->view('profilViewSuccesF',$data);
 	$this->load->view('templates/footerF');
 }
 

}
else{
 $this->load->view('templates/headerF');
 $this->load->view('profilViewErreurF',$data);
 $this->load->view('templates/footerF');

}



















 ///////////////////////////
 }


 }






 public function listerA()
 {
 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('mdp', 'mdp','required' );
 $this->form_validation->set_rules('mdp2', 'mdp2','required' );
 $this->form_validation->set_rules('nom', 'prenom','required' );
 $this->form_validation->set_rules('prenom', 'prenom','required' );
 $this->form_validation->set_rules('type', 'type','required' );
 $this->form_validation->set_rules('actif', 'actif','required' );

 $pseudo=$_SESSION['user'];
 $data['titre'] = $pseudo;
 $data['profil'] = $this->db_model->get_profil($pseudo);
if ($this->form_validation->run() == FALSE)
 {
 $data['test']=$this->form_validation->run();
 $this->load->view('templates/headerA');
 $this->load->view('profilViewA',$data);
 $this->load->view('templates/footerA');
 }
 else
 {
$pass1=htmlspecialchars(addslashes($this->input->post('mdp')));
$pass2=htmlspecialchars(addslashes($this->input->post('mdp2')));

//////////////////VERIF MOT DE PASSE





if ($pass1==$pass2) {

	//SEL
// On rajoute du sel...
// pour empêcher les attaques par "Rainbow Tables" cf
// http://en.wikipedia.org/wiki/Rainbow_table

$salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";

//HASHAGE
$PassAvantHash=$pass1;


 $_SESSION['PassAprésHash']=hash('sha256', $salt.$PassAvantHash);
 $pass=$_SESSION['PassAprésHash'];

 if ($this->db_model->update_profil($pseudo,$pass)) {
 	$data['profil'] = $this->db_model->get_profil($pseudo);
 	$this->load->view('templates/headerA');
 	$this->load->view('profilViewSuccesA',$data);
 	$this->load->view('templates/footerA');
 }
 

}
else{
 $this->load->view('templates/headerA');
 $this->load->view('profilViewErreurA',$data);
 $this->load->view('templates/footerA');

}



















 ///////////////////////////
 }


 }











public function creer()
 {
 $this->load->helper('form');
 $this->load->library('form_validation');
 $this->form_validation->set_rules('id', 'id', 'required');
 $this->form_validation->set_rules('mdp', 'mdp', 'required');
 if ($this->form_validation->run() == FALSE)
 {
 $this->load->view('templates/header');
 $this->load->view('compte_creer');
 $this->load->view('templates/footer');
 }
 else
 {
 $this->db_model->set_compte();
 $this->load->view('templates/header');
 $this->load->view('compte_succes');
 $this->load->view('templates/footer');
 }
}




 public function modifier()
 {

 $pseudo=$_SESSION['user'];
 $this->db_model->update_compte($pseudo);
 $data['titre'] = $pseudo;
 $data['profil'] = $this->db_model->get_profil($pseudo);

 $this->load->view('templates/headerF');
 $this->load->view('profilView',$data);
 $this->load->view('templates/footerF');
 }




/* public function lister()
 {
 $pseudo=$_SESSION['user'];
 $data['titre'] = $pseudo;
 $data['profil'] = $this->db_model->get_profil($pseudo);

 $this->load->view('templates/headerF');
 $this->load->view('profilView',$data);
 $this->load->view('templates/footerF');
 } */
















}
?>