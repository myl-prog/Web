<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Match extends CI_Controller {


 public function __construct()
 {
 parent::__construct();
 $this->load->model('db_model');
 $this->load->helper('url_helper');
 }

 public function listerA()
 {
 $data['titre'] = 'Liste des Matchs :';
 $data['match'] = $this->db_model->get_all_match();

 $this->load->view('templates/headerA');
 $this->load->view('matchViewA',$data);
 $this->load->view('templates/footerA');
 }



 public function listerF()
 {

 $data['titre'] = 'Liste de mes matchs :';
 $data['match'] = $this->db_model->get_matchF($_SESSION['user']);

 $this->load->view('templates/headerF');
 $this->load->view('matchViewF',$data);
 $this->load->view('templates/footerF');
 }




}
?>