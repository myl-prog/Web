<?php
class Db_model extends CI_Model {
 public function __construct()
 {
 $this->load->database();
 }







// -------------------GET-----------------









 public function get_all_compte()
{
$query = $this->db->query("SELECT CPT_PSEUDO,cpt_type,cpt_prenom,cpt_nom,cpt_actif FROM T_COMPTE_CPT");
return $query->result_array();
}





public function get_all_news()
{
$query = $this->db->query("SELECT ACT_ID,ACT_INTITULE,ACT_DESCRIPTIF FROM T_ACTUALITE_ACT;");
return $query->result_array();
}


public function get_matchF($match)
{
$query = $this->db->query("SELECT * FROM T_MATCH_MATCH WHERE
cpt_pseudo='".$match."';");
return $query->result_array();
}





public function get_match($match)
{
$query = $this->db->query("SELECT * FROM T_MATCH_MATCH WHERE
match_code='".$match."';");
return $query->result_array();
}





public function get_qst_rep($match)
{
$query = $this->db->query("SELECT QST_ID,QST_LIBELLE,REP_ID,REP_LIBELLE,REP_VALEUR FROM T_MATCH_MATCH JOIN T_QUIZ_QUIZ USING(quiz_id) JOIN T_QUESTIONS_QST USING(quiz_id) JOIN T_REPONSE_REP USING(qst_id) WHERE match_code='".$match."' ;");
return $query->result_array();
}





public function get_profil($pseudo)
{
$query = $this->db->query("SELECT * FROM T_COMPTE_CPT WHERE
cpt_pseudo='".$pseudo."';");
return $query->row();
}




public function get_score($match)
{
	$query=$this->db->query("SELECT jou_id,jou_pseudo,jou_score FROM T_JOUEUR_JOU NATURAL JOIN T_MATCH_MATCH WHERE match_code='".$match."' ;");
	return $query->result_array();
}


public function get_all_quiz()
{
	$query=$this->db->query("SELECT * FROM T_QUIZ_QUIZ  ;");
	return $query->result_array();
}

public function get_all_match()
{
$query = $this->db->query("SELECT * FROM T_MATCH_MATCH ;");
return $query->result_array();
}









// -------------Connect--------------





public function connect_compte($username, $password)
{

$this->db->where('cpt_pseudo', $username);
 $this->db->where('cpt_mdp', $password);
 $query = $this->db->get('T_COMPTE_CPT');
 if($query->num_rows() > 0)
 {
 return true;
 }
 else
 {
 return false;
 }
}


public function for_sinon_ad($arg)
{
	$F="F";
	$A="A";
	$queryF = $this->db->query("SELECT * FROM T_COMPTE_CPT WHERE cpt_pseudo='".$arg."' AND cpt_type='".$F."' ;");
	$queryA=$this->db->query("SELECT * FROM T_COMPTE_CPT WHERE cpt_pseudo='".$arg."' AND cpt_type='".$A."' ;");
	if($queryF->num_rows() > 0)
 {
 return true;
 }
 else if ($queryA->num_rows() > 0) 
 {
 return false;
 }

}



public function set_compte()
{
$id=$this->input->post('id');
$mdp=$this->input->post('mdp');
$req="INSERT INTO `T_COMPTE_CPT` VALUES ('".$id."','".$mdp."',NULL,NULL,NULL,NULL);";
$query = $this->db->query($req);
return ($query);
}






// ---------------------UPDATE--------------------


public function update_profil($pseudo,$pass)
{
$id=$this->input->post('id');
$mdp=$pass;
$nom=htmlspecialchars(addslashes($this->input->post('nom')));
$prenom=htmlspecialchars(addslashes($this->input->post('prenom')));
$type=htmlspecialchars(addslashes($this->input->post('type')));
$actif=htmlspecialchars(addslashes($this->input->post('actif')));


//$req="UPDATE `T_COMPTE_CPT` SET `cpt_pseudo`='".$id."',`cpt_mdp`='".$mdp."',`cpt_nom`='".$nom."',`cpt_prenom`='".$prenom."',`cpt_type`='".$type."',`cpt_actif`='".$actif."' WHERE cpt_pseudo='".$pseudo."';";
$req="UPDATE `T_COMPTE_CPT` SET `cpt_mdp`='".$mdp."',`cpt_nom`='".$nom."',`cpt_prenom`='".$prenom."',`cpt_actif`='".$actif."' WHERE cpt_pseudo='".$pseudo."';";

//$req="UPDATE `T_COMPTE_CPT` SET `cpt_mdp`='".$mdp."' WHERE cpt_pseudo='".$pseudo."';";
$query = $this->db->query($req);
return ($query);
}



public function update_match($match)
{

//$match=htmlspecialchars(addslashes($this->input->post('match')));
if (NULL!=$this->input->post('match_situation')){
$match_situation=htmlspecialchars(addslashes($this->input->post('match_situation')));
$req="UPDATE `T_MATCH_MATCH` SET `match_situation`='".$match_situation."' WHERE match_code='".$match."';";

$query = $this->db->query($req);

}
if (NULL!=$this->input->post('match_intitule')){
	$match_intitule=htmlspecialchars(addslashes($this->input->post('match_intitule')));
	$req="UPDATE `T_MATCH_MATCH` SET `match_intitule`='".$match_intitule."' WHERE match_code='".$match."';";

	$query = $this->db->query($req);

}







return 1;
}





public function update_quiz($quiz)
{

//$quiz=htmlspecialchars(addslashes($this->input->post('quiz')));


if (NULL!=$this->input->post('quiz_descriptif')){
$quiz_descriptif=htmlspecialchars(addslashes($this->input->post('quiz_descriptif')));
$req="UPDATE `T_QUIZ_QUIZ` SET `quiz_descriptif`='".$quiz_descriptif."' WHERE quiz_id='".$quiz."';";

$query = $this->db->query($req);

}

if (NULL!=$this->input->post('quiz_intitule')){
	$quiz_intitule=htmlspecialchars(addslashes($this->input->post('quiz_intitule')));
	$req="UPDATE `T_QUIZ_QUIZ` SET `quiz_intitule`='".$quiz_intitule."' WHERE quiz_id='".$quiz."';";

	$query = $this->db->query($req);

}

if (NULL!=$this->input->post('quiz_etat')){
$quiz_etat=htmlspecialchars(addslashes($this->input->post('quiz_etat')));
$req="UPDATE `T_QUIZ_QUIZ` SET `quiz_etat`='".$quiz_etat."' WHERE quiz_id='".$quiz."';";

$query = $this->db->query($req);

}









return 1;
}







public function update_profilNews($pseudo)
{
$id=$this->input->post('id');

$req="UPDATE `T_ACTUALITE_ACT` SET `cpt_pseudo`='".$id."' WHERE cpt_pseudo='".$pseudo."';";
$query = $this->db->query($req);
return ($query);
}


public function update_profilQuiz($pseudo)
{
$id=$this->input->post('id');

$req="UPDATE `T_QUIZ_QUIZ` SET `cpt_pseudo`='".$id."' WHERE cpt_pseudo='".$pseudo."';";
$query = $this->db->query($req);
return ($query);
}



public function update_profilMatch($pseudo)
{
$id=$this->input->post('id');
$req="UPDATE `T_MATCH_MATCH` SET `cpt_pseudo`='".$id."' WHERE cpt_pseudo='".$pseudo."';";
$query = $this->db->query($req);
return ($query);
}









// ---------------DELETE------------------


public function delete_Match($match)
{

$req="DELETE FROM `T_MATCH_MATCH` WHERE match_code='".$match."';";
$query = $this->db->query($req);
return ($query);
}




public function delete_Quiz($quiz)
{
$req="DELETE FROM T_REPONSE_REP WHERE qst_id in(SELECT qst_id FROM T_QUESTIONS_QST WHERE quiz_id='".$quiz."');";
$query = $this->db->query($req);

$req="DELETE FROM T_QUESTIONS_QST WHERE quiz_id='".$quiz."';";
$query = $this->db->query($req);

$req="DELETE FROM T_JOUEUR_JOU WHERE match_id in (SELECT match_id from T_MATCH_MATCH WHERE quiz_id='".$quiz."');";
$query = $this->db->query($req);

$req="DELETE FROM T_MATCH_MATCH WHERE quiz_id='".$quiz."';";
$query = $this->db->query($req);


$req="DELETE FROM `T_QUIZ_QUIZ` WHERE quiz_id='".$quiz."';";
$query = $this->db->query($req);
return ($query);
}




//------------INSERTION----------------



public function insert_quiz()
{	
	$user=$_SESSION['user'];
	$id=$this->input->post('quiz_id');
	$intitule=$this->input->post('quiz_intitule');
	$descriptif=$this->input->post('quiz_descriptif');
	$etat=$this->input->post('quiz_etat');
	$req="INSERT INTO `T_QUIZ_QUIZ`(`quiz_id`, `quiz_intitule`, `quiz_descriptif`, `quiz_img`, `quiz_etat`, `cpt_pseudo`) VALUES ('".$id."','".$intitule."','".$descriptif."',NULL,'".$etat."','".$user."');";
	$query=$this->db->query($req);
	return($query);
}




//--------Verification des resultats ---------

public function results($a,$b,$c,$d,$e,$match,$Q)
{	
	
	$score=0;
	$query = $this->db->query("SELECT QST_ID,QST_LIBELLE,REP_ID,REP_LIBELLE,REP_VALEUR FROM T_MATCH_MATCH JOIN T_QUIZ_QUIZ USING(quiz_id) JOIN T_QUESTIONS_QST USING(quiz_id) JOIN T_REPONSE_REP USING(qst_id) WHERE match_code='".$match."' AND REP_LIBELLE='".$e."' AND REP_VALEUR=1  AND qst_id='".$Q."' ; ");
	
	
	if($query->num_rows() > 0)
 {
 $score++;
 }
 	$Q--;
 $query = $this->db->query("SELECT QST_ID,QST_LIBELLE,REP_ID,REP_LIBELLE,REP_VALEUR FROM T_MATCH_MATCH JOIN T_QUIZ_QUIZ USING(quiz_id) JOIN T_QUESTIONS_QST USING(quiz_id) JOIN T_REPONSE_REP USING(qst_id) WHERE match_code='".$match."' AND REP_LIBELLE='".$d."' AND REP_VALEUR=1  AND qst_id='".$Q."' ;");

	
	if($query->num_rows() > 0)
 {
 $score++;
 }
 	$Q--;
 $query = $this->db->query("SELECT QST_ID,QST_LIBELLE,REP_ID,REP_LIBELLE,REP_VALEUR FROM T_MATCH_MATCH JOIN T_QUIZ_QUIZ USING(quiz_id) JOIN T_QUESTIONS_QST USING(quiz_id) JOIN T_REPONSE_REP USING(qst_id) WHERE match_code='".$match."' AND REP_LIBELLE='".$c."' AND REP_VALEUR=1  AND qst_id='".$Q."' ;");

	
	if($query->num_rows() > 0)
 {
 $score++;
 }
 	$Q--;
 $query = $this->db->query("SELECT QST_ID,QST_LIBELLE,REP_ID,REP_LIBELLE,REP_VALEUR FROM T_MATCH_MATCH JOIN T_QUIZ_QUIZ USING(quiz_id) JOIN T_QUESTIONS_QST USING(quiz_id) JOIN T_REPONSE_REP USING(qst_id) WHERE match_code='".$match."' AND REP_LIBELLE='".$b."' AND REP_VALEUR=1  AND qst_id='".$Q."' ;");

	
	if($query->num_rows() > 0)
 {
 $score++;
 }
 	$Q--;
 $query = $this->db->query("SELECT QST_ID,QST_LIBELLE,REP_ID,REP_LIBELLE,REP_VALEUR FROM T_MATCH_MATCH JOIN T_QUIZ_QUIZ USING(quiz_id) JOIN T_QUESTIONS_QST USING(quiz_id) JOIN T_REPONSE_REP USING(qst_id) WHERE match_code='".$match."' AND REP_LIBELLE='".$a."' AND REP_VALEUR=1 AND qst_id='".$Q."'  ;");

	
	if($query->num_rows() > 0)
 {
 $score++;
 }
return $score;
}

}
?>
